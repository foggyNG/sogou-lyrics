#!/bin/bash

echo ">>> testcase mdp"
./mdp mdp.in mdp.out

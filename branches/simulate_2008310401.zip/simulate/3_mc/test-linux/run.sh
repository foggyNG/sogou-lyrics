#!/bin/bash

echo ">>> testcase mc1"
./mc mc1.in mc1.out
echo ">>> testcase mc2"
./mc mc2.in mc2.out
echo ">>> testcase mc3"
./mc mc3.in mc3.out

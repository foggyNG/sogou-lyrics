#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

/**
 * assign state according to distribution
 * 
 * @param m number of states
 * @param p distribution
 * @return randomly assigned state
 */
size_t roulette(size_t m, double *p)
{
	size_t state = 0, i;
	double sum = 0.0f;
	for (i=0;i<m;i++) sum += p[i];
	for (i=0;i<m;i++) p[i] /= sum;
	double temp1 = p[0], temp2 = (double)rand()/RAND_MAX;
	while(state<m && temp2>temp1)
	{
		state++;
		temp1 += p[state];
	}
	return state;
}

/**
 * generate markov chain sequence using mcmc
 * 
 * @param m number of states
 * @param n length of sequence
 * @param pi stable distribution
 * @param t transform matrix
 * @param seq output sequence container
 */ 
void mcmc(size_t m, size_t n, double *pi, double **t, vector<size_t>& seq)
{
	size_t state = roulette(m, pi), y;
	double rho;
	while(seq.size()<n)
	{
		y = roulette(m, t[state]);
		rho = min(1.0, pi[y]*t[y][state] / (pi[state]*t[state][y]));
		double temp = (double)rand()/RAND_MAX;
		if ( temp < rho)
		{
			state = y;
			seq.push_back(state);
		}
	}
}

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		cerr <<"Usage: mcmc <infile> <outfile>"<<endl;
		return 1;
	}
	srand(time(NULL));
	ifstream fin(argv[1]);
	ofstream fout(argv[2]);
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		size_t m, n, i, j;
		vector<size_t> seq;
		seq.clear();
		double *pi = NULL, **t = NULL;
		// read parameters
		fin >>m>>n;
		pi = new double[m];
		t = new double*[m];
		for (i=0;i<m;i++) t[i] = new double[m];
		for (i=0;i<m;i++) fin >>pi[i];
		for (i=0;i<m;i++)
			for (j=0;j<m;j++)
				fin >>t[i][j];
		fin.close();
		// generate sequence
		mcmc(m, n, pi, t, seq);
		// output result
		vector<size_t>::iterator ita = seq.begin();
		for (;ita!=seq.end();ita++)
		{
			fout <<(*ita)+1<<endl;
		}
		delete[] pi;
		for (i=0;i<m;i++) delete[] t[i];
		delete[] t;
		fout.close();
	}
	return 0;
}

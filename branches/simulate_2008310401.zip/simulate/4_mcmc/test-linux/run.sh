#!/bin/bash

echo ">>> testcase mcmc1"
./mcmc mcmc1.in mcmc1.out
echo ">>> testcase mcmc2"
./mcmc mcmc2.in mcmc2.out
echo ">>> testcase mcmc3"
./mcmc mcmc3.in mcmc3.out

#!/bin/bash

echo ">>> testcase mcdi"
./mcdi mcdi.in mcdi.out

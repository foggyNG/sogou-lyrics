#!/bin/bash

echo ">>> testcase pp1"
./pp pp1.in pp1.out
echo ">>> testcase pp2"
./pp pp2.in pp2.out
echo ">>> testcase pp3"
./pp pp3.in pp3.out

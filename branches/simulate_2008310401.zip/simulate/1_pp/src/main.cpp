#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

/** generate poisson sequence
 * 
 * @param lambda poisson process parameter lambda
 * @param n length of sequence
 * @param seq output sequence container
 */
void pp(float lambda, size_t n, vector<float>& seq)
{
	float current = 0.0f;
	size_t i = 0;
	for (;i<n;i++)
	{
		current += - log((float)rand()/RAND_MAX) / lambda;
		seq.push_back(current);
	}
}

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		cerr <<"Usage: pp <infile> <outfile>"<<endl;
		return 1;
	}
	srand(time(NULL));
	ifstream fin(argv[1]);
	ofstream fout(argv[2]);
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		float lambda = 0.0f;
		size_t n = 0;
		vector<float> seq;
		seq.clear();
		// read parameters
		fin >>lambda>>n;
		fin.close();
		// generate poisson sequence
		pp(lambda, n, seq);
		// output result
		vector<float>::iterator i = seq.begin();
		fout.setf(ios::fixed);
		fout.precision(6);
		for (;i!=seq.end();i++)
		{
			fout <<*i<<endl;
		}
		fout.close();
	}
	return 0;
}

姓名:曹彬彬
学号:2008310401
班级:计研84
电话:13466338275
电子邮箱:gogo.wonder@gmail.com

文件说明：
report.pdf	实验报告
src/	源代码目录
tex/	实验报告源代码目录
test-linux/	可执行文件及测试目录(linux版本)
test-linux/pp	可执行文件(linux gcc 4.3.3)
test-linux/run.sh	测试脚本(linux bash)
test-linux/pp*.in	测试样例输入
test-linux/pp*.out	测试样例输出
test-win/	可执行文件及测试目录(windows版本)
test-win/pp.exe	可执行文件(visual studio c++ express 2005)
test-win/run.bat	测试脚本
test-win/pp*.in	测试样例输入
test-win/pp*.out	测试样例输出

运行方法：
pp <infile> <outfile>
例如：pp pp1.in pp1.out




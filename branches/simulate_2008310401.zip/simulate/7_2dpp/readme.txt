姓名:曹彬彬
学号:2008310401
班级:计研84
电话:13466338275
电子邮箱:gogo.wonder@gmail.com

文件说明：
report.pdf	实验报告
src/	源代码目录
tex/	实验报告源代码目录
test-linux/	可执行文件及测试目录(linux版本)
test-linux/2dpp	可执行文件(linux gcc 4.3.3)
test-linux/run.sh	测试脚本(linux bash)
test-linux/2dpp.in	测试样例输入
test-linux/2dpp.out	测试样例输出
test-win/	可执行文件及测试目录(windows版本)
test-win/2dpp.exe	可执行文件(visual studio c++ express 2005)
test-win/run.bat	测试脚本
test-win/2dpp.in	测试样例输入
test-win/2dpp.out	测试样例输出

运行方法：
2dpp <infile> <outfile>
例如：2dpp 2dpp.in 2dpp.out




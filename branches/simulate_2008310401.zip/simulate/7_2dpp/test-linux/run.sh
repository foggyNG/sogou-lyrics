#!/bin/bash

echo ">>> testcase 2dpp"
./2dpp 2dpp.in 2dpp.out

#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cstring>
using namespace std;

/**
 * assign state according to distribution
 * 
 * @param m number of states
 * @param p distribution
 * @return randomly assigned state
 */
size_t roulette(size_t m, double *p)
{
	size_t state = 0, i;
	double sum = 0.0f;
	for (i=0;i<m;i++) sum += p[i];
	for (i=0;i<m;i++) p[i] /= sum;
	double temp1 = p[0], temp2 = (double)rand()/RAND_MAX;
	while(state<m && temp2>temp1)
	{
		state++;
		temp1 += p[state];
	}
	return state;
}

/**
 * generate continous parameter markov chain sequence
 * 
 * @param m number of states
 * @param n length of sequence
 * @param pi0 initial distribution
 * @param q transform matrix
 * @param seq output sequence container
 */
void cpmc(size_t m, size_t n, double *pi0, double **q, vector<pair<size_t, double> >& seq)
{
	size_t state = roulette(m, pi0), i;
	double t = 0.0f, *pstate = new double[m];
	seq.push_back(make_pair<size_t, double>(state, t));
	for (i=1;i<n;i++)
	{
		memcpy(pstate, q[state], sizeof(double)*m);
		pstate[state] = 0;
		t += log((double)rand()/RAND_MAX) / q[state][state];
		state = roulette(m, pstate);
		seq.push_back(make_pair<size_t, double>(state, t));
	}
	delete[] pstate;
}

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		cerr <<"Usage: cpmc <infile> <outfile>"<<endl;
		return 1;
	}
	srand(time(NULL));
	ifstream fin(argv[1]);
	ofstream fout(argv[2]);
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		size_t m, n, i, j;
		vector<pair<size_t, double> > seq;
		seq.clear();
		double *pi0 = NULL, **q = NULL;
		// read parameters
		fin >>m>>n;
		pi0 = new double[m];
		q = new double*[m];
		for (i=0;i<m;i++) q[i] = new double[m];
		for (i=0;i<m;i++) fin >>pi0[i];
		for (i=0;i<m;i++)
			for (j=0;j<m;j++)
				fin >>q[i][j];
		fin.close();
		// generate sequence
		cpmc(m, n, pi0, q, seq);
		// output result
		fout.setf(ios::fixed);
		fout.precision(6);
		vector<pair<size_t, double> >::iterator ita = seq.begin();
		for (;ita!=seq.end();ita++)
		{
			fout <<ita->first+1<<' '<<ita->second<<endl;
		}
		delete[] pi0;
		for (i=0;i<m;i++) delete[] q[i];
		delete[] q;
		fout.close();
	}
	return 0;
}

#!/bin/bash

echo ">>> testcase cpmc1"
./cpmc cpmc1.in cpmc1.out
echo ">>> testcase cpmc2"
./cpmc cpmc2.in cpmc2.out
echo ">>> testcase cpmc3"
./cpmc cpmc3.in cpmc3.out

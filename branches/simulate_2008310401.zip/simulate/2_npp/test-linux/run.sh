#!/bin/bash

echo ">>> testcase npp1"
./npp npp1.in npp1.out
echo ">>> testcase npp2"
./npp npp2.in npp2.out
echo ">>> testcase npp3"
./npp npp3.in npp3.out

#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;
#define _USE_MATH_DEFINES
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/**
 * non-homogeneous poisson process simulation
 * 
 * @param a,omega,theta,b density function a*sin(omega*t+theta*pi)+b
 * @param n length of sequence
 * @param seq output poisson process sequence
 */
void npp(float a, float omega, float theta, float b, size_t n, vector<float>& seq)
{
	float current = 0.0f;
	size_t i = 0, threshold = abs(a)+abs(b);
	while(i<n)
	{
		current += - log((float)rand()/RAND_MAX) / threshold;
		if ((float)rand()/RAND_MAX*threshold > a*sin(omega*current+theta*M_PI)+b) continue;
		else
		{
			seq.push_back(current);
			i ++;
		}
	}
}

int main(int argc, char **argv)
{
	if (argc != 3)
	{
		cerr <<"Usage: npp <infile> <outfile>"<<endl;
		return 1;
	}
	srand(time(NULL));
	ifstream fin(argv[1]);
	ofstream fout(argv[2]);
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		float a = 0.0f, omega = 0.0f, theta = 0.0f, b = 0.0f;
		size_t n = 0;
		vector<float> seq;
		seq.clear();
		// read parameters
		fin >>a>>omega>>theta>>b>>n;
		fin.close();
		// generate poisson sequence
		npp(a, omega, theta, b, n, seq);
		// output result
		vector<float>::iterator i = seq.begin();
		fout.setf(ios::fixed);
		fout.precision(6);
		for (;i!=seq.end();i++)
		{
			fout <<*i<<endl;
		}
		fout.close();
	}
	return 0;
}

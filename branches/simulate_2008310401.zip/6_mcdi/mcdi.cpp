#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

double mcdi1(double a, double b, size_t n, vector<pair<double, double> >& vec)
{
	double m1=0.0f, m2=1.0f;
	size_t count = 0, i;
	double x,y;
	for (i=0;i<n;i++)
	{
		x=(double)rand()/RAND_MAX*(b-a)+a;
		y=(double)rand()/RAND_MAX*(m2-m1)+m1;
		vec.push_back(make_pair<double, double>(x,y));
		count += (y <= exp(-x*x));
	}
	return (b-a)*(m2-m1)*count/n;
}

double mcdi2(double a, double b, size_t n, vector<double>& vec)
{
	double ans = 0.0f, eta, f;
	size_t i;
	for (i=0;i<n;i++)
	{
		eta = (double)rand()/RAND_MAX*(b-a)+a;
		f = exp(-eta*eta);
		ans += f;
		vec.push_back(f);
	}
	return ans*(b-a)/n;
}

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));
	ifstream fin("mcdi.in");
	ofstream fout("mcdi.out");
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		double a = 0.0f, b = 0.0f;
		size_t n = 0;
		// read parameters
		fin >>a>>b>>n;
		fin.close();
		// calculate
		vector<pair<double, double> > vec1;
		vec1.clear();
		vector<double> vec2;
		vec2.clear();
		double ans1 = mcdi1(a,b,n,vec1);
		double ans2 = mcdi2(a,b,n,vec2);
		// output result
		fout.setf(ios::fixed);
		fout.precision(6);
		fout <<ans1<<endl;
		vector<pair<double, double> >::iterator i = vec1.begin();
		for (;i!=vec1.end();i++)
		{
			fout <<i->first<<' '<<i->second<<endl;
		}
		fout <<ans2<<endl;
		vector<double>::iterator j = vec2.begin();
		for (;j!=vec2.end();j++)
		{
			fout <<*j<<endl;
		}
		fout.close();
	}
	return 0;
}


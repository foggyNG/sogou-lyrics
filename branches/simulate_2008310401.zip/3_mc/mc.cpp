#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

/**
 * assign state according to distribution
 * 
 * @param m number of states
 * @param p distribution
 * @return randomly assigned state
 */
size_t roulette(size_t m, double *p)
{
	size_t state = 0, i;
	double sum = 0.0f;
	for (i=0;i<m;i++) sum += p[i];
	for (i=0;i<m;i++) p[i] /= sum;
	double temp1 = p[0], temp2 = (double)rand()/RAND_MAX;
	while(state<m && temp2>temp1)
	{
		state++;
		temp1 += p[state];
	}
	return state;
}

/**
 * generate markov chain sequence
 * 
 * @param m number of states
 * @param n length of sequence
 * @param pi0 initial distribution
 * @param p transform matrix
 * @param seq output sequence container
 */ 
void mc(size_t m, size_t n, double *pi0, double **p, vector<size_t>& seq)
{
	size_t state = roulette(m, pi0), i;
	seq.push_back(state);
	for (i=1;i<n;i++)
	{
		state = roulette(m, p[state]);
		seq.push_back(state);
	}
}

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));
	ifstream fin("mc.in");
	ofstream fout("mc.out");
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		size_t m, n, i, j;
		vector<size_t> seq;
		seq.clear();
		double *pi0 = NULL, **p = NULL;
		// read parameters
		fin >>m>>n;
		pi0 = new double[m];
		p = new double*[m];
		for (i=0;i<m;i++) p[i] = new double[m];
		for (i=0;i<m;i++) fin >>pi0[i];
		for (i=0;i<m;i++)
			for (j=0;j<m;j++)
				fin >>p[i][j];
		fin.close();
		// generate mc sequence
		mc(m, n, pi0, p, seq);
		// output result
		vector<size_t>::iterator ita = seq.begin();
		for (;ita!=seq.end();ita++)
		{
			fout <<(*ita)+1<<endl;
		}
		delete[] pi0;
		for (i=0;i<m;i++) delete[] p[i];
		delete[] p;
		fout.close();
	}
	return 0;
}

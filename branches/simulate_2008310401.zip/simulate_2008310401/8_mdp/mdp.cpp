#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <float.h>
#include <cstring>
using namespace std;
double ria1(size_t state)
{
	return 2.0*(state+1.0);
}
double ria2(size_t state)
{
	return (state+1.0)*(state+1.0)+1.0/2;
}
double ria3(size_t state)
{
	return 2.0*pow(state+1.0, 2.0/3);
}
double ria4(size_t state)
{
	return 1.0/sin(state+1.0);
}
size_t roulette(size_t m, double *p)
{
	size_t state = 0, i;
	double sum = 0.0f;
	for (i=0;i<m;i++) sum += p[i];
	for (i=0;i<m;i++) p[i] /= sum;
	double temp1 = p[0], temp2 = (double)rand()/RAND_MAX;
	while(state<m && temp2>temp1)
	{
		state++;
		temp1 += p[state];
	}
	return state;
}

double mdp(size_t s, size_t a, size_t n, double (**ria)(size_t), double ***pa, size_t **decision)
{
	double *unlast = new double[s], *uncurrent = new double[s], temp;
	size_t i,j,k,x;
	for (i=0;i<s;i++) unlast[i] = 0.0;
	//
	for (j=0;j<s;j++)
	{
		uncurrent[j] = -DBL_MAX;
		decision[n-1][j] = INT_MAX;
		for (k=0;k<a;k++)
		{
			temp = ria[k](j);
			if (temp > uncurrent[j])
			{
				uncurrent[j] = temp;
				decision[n-1][j] = k;
			}
		}
	}
	//
	for (i=n-1;i>0;i--)
	{
		memcpy(unlast, uncurrent, sizeof(double)*s);
		for (j=0;j<s;j++)
		{
			uncurrent[j] = -DBL_MAX;
			decision[i-1][j] = INT_MAX;
			for (k=0;k<a;k++)
			{
				temp = ria[k](j);
				for (x=0;x<s;x++) temp += pa[k][j][x] * unlast[x];
				if (temp > uncurrent[j])
				{
					uncurrent[j] = temp;
					decision[i-1][j] = k;
				}
			}
		}
	}
	double expect = -DBL_MAX;
	for (i=0;i<s;i++) expect = max(expect, uncurrent[i]);
	return expect;
}

double mdpmc(size_t s, size_t a, size_t n, double (**ria)(size_t), double ***pa, double *pi0, size_t **decision, vector<size_t>& seq)
{
	size_t state = roulette(s, pi0), i;
	double profit = ria[decision[0][state]](state);
	seq.push_back(state);
	for (i=1;i<n;i++)
	{
		state = roulette(s, pa[decision[i-1][state]][state]);
		profit += ria[decision[i][state]](state);
		seq.push_back(state);
	}
	return profit;
}

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));
	ifstream fin("mdp.in");
	ofstream fout("mdp.out");
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		size_t s = 3, a = 4, n, i, j;
		double ***pa = new double**[a];
		for (i=0;i<a;i++)
		{
			pa[i] = new double*[s];
			for (j=0;j<s;j++) pa[i][j] = new double[s];
		}
		pa[0][0][0] = 1.0/2;
		pa[0][0][1] = 1.0/2;
		pa[0][0][2] = 0.0;
		pa[0][1][0] = 0.0;
		pa[0][1][1] = 1.0/2;
		pa[0][1][2] = 1.0/2;
		pa[0][2][0] = 1.0/2;
		pa[0][2][1] = 0.0;
		pa[0][2][2] = 1.0/2;
		//
		pa[1][0][0] = 1.0/2;
		pa[1][0][1] = 0.0;
		pa[1][0][2] = 1.0/2;
		pa[1][1][0] = 1.0/2;
		pa[1][1][1] = 1.0/2;
		pa[1][1][2] = 0.0;
		pa[1][2][0] = 0.0;
		pa[1][2][1] = 1.0/2;
		pa[1][2][2] = 1.0/2;
		//
		pa[2][0][0] = 1.0/3;
		pa[2][0][1] = 2.0/3;
		pa[2][0][2] = 0.0;
		pa[2][1][0] = 0.0;
		pa[2][1][1] = 1.0/3;
		pa[2][1][2] = 2.0/3;
		pa[2][2][0] = 1.0/3;
		pa[2][2][1] = 0.0;
		pa[2][2][2] = 2.0/3;
		//
		pa[3][0][0] = 2.0/3;
		pa[3][0][1] = 0.0;
		pa[3][0][2] = 1.0/3;
		pa[3][1][0] = 2.0/3;
		pa[3][1][1] = 1.0/3;
		pa[3][1][2] = 0.0;
		pa[3][2][0] = 0.0;
		pa[3][2][1] = 2.0/3;
		pa[3][2][2] = 1.0/3;
		
		vector<size_t> seq;
		seq.clear();
		double *pi0 = NULL;
		size_t **decision = NULL;
		// read parameters
		pi0 = new double[s];
		for (i=0;i<s;i++) fin >> pi0[i];
		fin >>n;
		fin.close();
		decision = new size_t*[n];
		for (i=0;i<n;i++) decision[i] = new size_t[s];
		double (*ria[])(size_t) = {ria1, ria2, ria3, ria4};
		// generate poisson sequence
		double expect = mdp(s, a, n, ria, pa, decision);
		double actual = mdpmc(s, a, n, ria, pa, pi0, decision, seq);
		// output result
		fout.setf(ios::fixed);
		fout.precision(6);
		for (i=0;i<n;i++)
		{
			for (j=0;j<s;j++) fout <<decision[i][j]+1<<' ';
			fout <<endl;
		}
		fout <<expect<<endl;
		vector<size_t>::iterator ita = seq.begin();
		for (;ita!=seq.end();ita++)
		{
			fout <<(*ita)+1<<' ';
		}
		fout <<endl<<actual;
		//
		delete[] pi0;
		for (i=0;i<n;i++) delete[] decision[i];
		delete[] decision;
		for (i=0;i<a;i++)
		{
			for (j=0;j<s;j++) delete[] pa[i][j];
			delete[] pa[i];
		}
		delete[] pa;
		fout.close();
	}
	return 0;
}

#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;
#define _USE_MATH_DEFINES
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void bidpp(double lambda, size_t n, vector<pair<double, double> >& vec)
{
	double area = 0.0f, radius = 0.0f;
	double angle = 0.0f;
	size_t i;
	for (i=0;i<n;i++)
	{
		area += - log((double)rand()/RAND_MAX) / lambda;
		radius = sqrt(area/M_PI);
		angle = 2*M_PI*rand()/RAND_MAX;
		vec.push_back(make_pair<double, double>(radius*cos(angle), radius*sin(angle)));
	}
}

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));
	ifstream fin("2dpp.in");
	ofstream fout("2dpp.out");
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		double lambda = 0.0f;
		size_t n = 0;
		// read parameters
		fin >>lambda>>n;
		fin.close();
		// generate sequence
		vector<pair<double, double> > vec;
		vec.clear();
		bidpp(lambda,n,vec);
		// output result
		fout.setf(ios::fixed);
		fout.precision(6);
		vector<pair<double, double> >::iterator i = vec.begin();
		for (;i!=vec.end();i++)
		{
			fout <<i->first<<' '<<i->second<<endl;
		}
		fout.close();
	}
	return 0;
}

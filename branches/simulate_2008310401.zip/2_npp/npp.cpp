#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;
#define _USE_MATH_DEFINES
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/**
 * non-homogeneous poisson process simulation
 * 
 * @param a,omega,theta,b density function a*sin(omega*t+theta*pi)+b
 * @param n length of sequence
 * @param seq output poisson process sequence
 */
void npp(double a, double omega, double theta, double b, size_t n, vector<double>& seq)
{
	double current = 0.0f;
	size_t i = 0;
	double threshold = abs(a)+abs(b);
	while(i<n)
	{
		current += - log(((double)rand()+1.0)/((double)RAND_MAX+1.0)) / threshold;
		if ((double)rand()/RAND_MAX*threshold > a*sin(omega*current+theta*M_PI)+b) continue;
		else
		{
			seq.push_back(current);
			i ++;
		}
	}
}

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));
	ifstream fin("npp.in");
	ofstream fout("npp.out");
	if (!fin || !fout)
	{
		cerr << "invalid filename" <<endl;
	}
	else
	{
		// allocate parameters
		double a = 0.0f, omega = 0.0f, theta = 0.0f, b = 0.0f;
		size_t n = 0;
		vector<double> seq;
		seq.clear();
		// read parameters
		fin >>a>>omega>>theta>>b>>n;
		fin.close();
		// generate poisson sequence
		npp(a, omega, theta, b, n, seq);
		// output result
		vector<double>::iterator i = seq.begin();
		fout.setf(ios::fixed);
		fout.precision(6);
		for (;i!=seq.end();i++)
		{
			fout <<*i<<endl;
		}
		fout.close();
	}
	return 0;
}
